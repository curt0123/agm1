#ifndef ARGON2_CUDA_KERNELS_H
#define ARGON2_CUDA_KERNELS_H

#if HAVE_CUDA

#include <cuda_runtime.h>
#include <cstdint>
#include <argon2-gpu-common/argon2-common.h>

/* workaround weird CMake/CUDA bug: */
#ifdef argon2
#undef argon2
#endif

namespace argon2 {
namespace cuda {

class KernelRunner
{
private:
    std::uint32_t type, version;
    std::uint32_t passes, lanes, segmentBlocks;
    std::uint32_t batchSize;
    bool bySegment;
    
    t_optParams optParams;

    cudaEvent_t start, end;
    cudaStream_t stream;
    void *memory;
    void *refs;
    void precomputeRefs();
    void initializeBuffers();
    void freeBuffers();
    
    uint32_t getBlockCount() const;
    size_t totalRefsSize() const;

    void runKernelSegment(std::uint32_t lanesPerBlock,
                          std::uint32_t jobsPerBlock,
                          std::uint32_t pass, std::uint32_t slice);
    void runKernelOneshot(std::uint32_t lanesPerBlock,
                          std::uint32_t jobsPerBlock);

public:
    KernelRunner(std::uint32_t type, std::uint32_t version,
                 std::uint32_t passes, std::uint32_t lanes,
                 std::uint32_t segmentBlocks, std::uint32_t batchSize,
                 bool bySegment, t_optParams optParams);

    ~KernelRunner();

    std::uint32_t getMinLanesPerBlock() const { return bySegment ? 1 : lanes; }
    std::uint32_t getMaxLanesPerBlock() const { return lanes; }
    std::uint32_t getMinJobsPerBlock() const { return 1; }
    std::uint32_t getMaxJobsPerBlock() const { return batchSize; }
    std::uint32_t getBatchSize() const { return batchSize; }

    void writeInputMemory(std::uint32_t jobId, const void *buffer);
    void readOutputMemory(std::uint32_t jobId, void *buffer);
    void syncStream();
    bool streamOperationsComplete();

    void run(std::uint32_t lanesPerBlock, std::uint32_t jobsPerBlock);
    float finish();

    void reconfigureArgon(
        std::uint32_t passes,
        std::uint32_t lanes,
        std::uint32_t segmentBlocks,
        std::uint32_t newBatchSize,
        const t_optParams &optParams);

    size_t getMemoryUsage() const;
    size_t getMemoryUsedPerBatch() const;
};

} // cuda
} // argon2

#endif /* HAVE_CUDA */

#endif // ARGON2_CUDA_KERNELS_H
