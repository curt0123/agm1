#ifndef ARGON2_CUDA_PROCESSINGUNIT_H
#define ARGON2_CUDA_PROCESSINGUNIT_H

#if HAVE_CUDA

#include <memory>

#include "programcontext.h"
#include "kernels.h"
#include "argon2-gpu-common/argon2params.h"

namespace argon2 {
namespace cuda {

class ProcessingUnit
{
private:
    const ProgramContext *programContext;
    const Argon2Params *params;
    const Device *device;

    KernelRunner runner;
    std::uint32_t bestLanesPerBlock;
    std::uint32_t bestJobsPerBlock;
    std::vector<uint8_t*> setPasswordBuffers;

public:
    std::size_t getBatchSize() const { return runner.getBatchSize(); }

    ProcessingUnit(
            const ProgramContext *programContext, const Argon2Params *params,
            const Device *device, std::size_t batchSize, bool bySegment,
            const t_optParams &optPrms);

    void setPassword(std::size_t index, const void *pw, std::size_t pwSize);

    void fetchResultAsync(std::size_t index, void *dest);
    void syncStream();
    bool streamOperationsComplete();

    void beginProcessing();
    void endProcessing();
    void reconfigureArgon(
        const Argon2Params *newParams,
        std::uint32_t batchSize,
        const t_optParams &optParams);

    size_t getMemoryUsage() const;
    size_t getMemoryUsedPerBatch() const;
};

} // namespace cuda
} // namespace argon2

#else

#include <cstddef>

#include "programcontext.h"
#include "argon2-gpu-common/argon2params.h"

namespace argon2 {
namespace cuda {

class ProcessingUnit
{
public:
    std::size_t getBatchSize() const { return 0; }

    ProcessingUnit(
            const ProgramContext *programContext, const Argon2Params *params,
            const Device *device, std::size_t batchSize,
            bool bySegment = true, bool precomputeRefs = false)
    {
    }

    void setPassword(std::size_t index, const void *pw, std::size_t pwSize) { }

    void getHash(std::size_t index, void *hash) { }

    void beginProcessing() { }
    void endProcessing() { }
};

} // namespace cuda
} // namespace argon2

#endif /* HAVE_CUDA */

#endif // ARGON2_CUDA_PROCESSINGUNIT_H
