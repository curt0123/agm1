#ifndef ARGON2_OPENCL_KERNELRUNNER_H
#define ARGON2_OPENCL_KERNELRUNNER_H

#include "programcontext.h"
#include "argon2-gpu-common/argon2params.h"

namespace argon2 {
namespace opencl {

class KernelRunner
{
private:
    const ProgramContext *programContext;
    const Argon2Params *params;

    std::uint32_t batchSize;
    bool bySegment;

    cl::CommandQueue *queue;
    cl::Kernel kernel;
    cl::Buffer memoryBuffer, refsBuffer;

    cl::Event end;

    t_optParams optParams;

    void setKernelsArgs();
    size_t totalRefsSize() const;
    void precomputeRefs();
    void initializeBuffers();
    void setupKernel(const Device *device);
    void freeBuffers();


public:
    std::uint32_t getMinLanesPerBlock() const
    {
        return bySegment ? 1 : params->getLanes();
    }
    std::uint32_t getMaxLanesPerBlock() const { return params->getLanes(); }

    std::uint32_t getMinJobsPerBlock() const { return 1; }
    std::uint32_t getMaxJobsPerBlock() const { return batchSize; }

    std::uint32_t getBatchSize() const { return batchSize; }

    KernelRunner(const ProgramContext *programContext,
                 const Argon2Params *params, const Device *device,
                 std::uint32_t batchSize, bool bySegment, t_optParams opt);

    void uploadToInputMemoryAsync(std::uint32_t jobId, const void* srcPtr);
    void fetchOutputMemoryAsync(std::uint32_t jobId, void* dstPtr);

    void run(std::uint32_t lanesPerBlock, std::uint32_t jobsPerBlock);

    void waitForResults();
    bool resultsReady();
    void insertEndEventAndFlush();

    void reconfigureArgon(
        const Device *device,
        const Argon2Params *newParams,
        std::uint32_t newBatchSize,
        const t_optParams &newOptParams);
    
    size_t getMemoryUsage() const;
    size_t getMemoryUsedPerBatch() const;
    uint32_t getBlockCount() const;

    cl::CommandQueue *getQueue() {
        return queue;
    }
};

} // namespace opencl
} // namespace argon2

#endif // ARGON2_OPENCL_KERNELRUNNER_H
