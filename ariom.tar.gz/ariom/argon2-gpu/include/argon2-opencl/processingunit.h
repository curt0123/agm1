#ifndef ARGON2_OPENCL_PROCESSINGUNIT_H
#define ARGON2_OPENCL_PROCESSINGUNIT_H

#include <memory>

#include "kernelrunner.h"

namespace argon2 {
namespace opencl {

class ProcessingUnit
{
private:
    const ProgramContext *programContext;
    const Argon2Params *params;
    const Device *device;

    KernelRunner runner;
    std::uint32_t bestLanesPerBlock;
    std::uint32_t bestJobsPerBlock;

    cl::Buffer setPasswordBuffer;
    uint8_t* passwordsPtr;

    cl::Buffer resultBuffer;
    uint8_t* resultsPtr;

    std::size_t getStartBlocksSize();

public:
    std::size_t getBatchSize() const { return runner.getBatchSize(); }

    ProcessingUnit(
            const ProgramContext *programContext, const Argon2Params *params,
            const Device *device, std::size_t batchSize,
            bool bySegment, const t_optParams& optPrms);

    void setPassword(std::size_t index, const void *pw, std::size_t pwSize);

    void runKernelAsync();
    void fetchResultAsync(std::size_t index);

    void waitForResults();
    bool resultsReady();

    void reconfigureArgon(
        const Argon2Params *newParams,
        std::uint32_t batchSize,
        const t_optParams &optParams);
    
    size_t getMemoryUsage() const;
    size_t getMemoryUsedPerBatch() const;
    uint8_t* getResultPtr(int jobId);
};

} // namespace opencl
} // namespace argon2

#endif // ARGON2_OPENCL_PROCESSINGUNIT_H
